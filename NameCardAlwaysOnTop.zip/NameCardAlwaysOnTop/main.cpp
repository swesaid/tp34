#include <windows.h>
#include <iostream>

int main()
{
    const char* notepadWindowTitle = "name.txt - Notepad"; 
    bool notepadFoundInitially = false;

    try
    {
        while (true)
        {
            HWND notepadWindow = FindWindowA(NULL, notepadWindowTitle);

            if (notepadWindow != NULL) 
            {
                if (!notepadFoundInitially) 
                {
                    std::cout << "Notepad window with the\"" << notepadWindowTitle << "\" file was found." << std::endl;
                    notepadFoundInitially = true;
                }

                //If the Notepad window is minimized, we will restore it.
                if (IsIconic(notepadWindow)) 
                    ShowWindow(notepadWindow, SW_RESTORE);
  

                SetWindowPos(notepadWindow, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE);
            }
            else 
            {
                //If user closes the Notepad, the appropriate message will be printed.
                if (notepadFoundInitially) 
                {
                    std::cout << "You closed Notepad." << std::endl;
                    std::cout << "Terminating the app..." << std::endl;
                    Sleep(1000);
                    return 0;
                }
                else 
                {
                    // If Notepad was not open during the app run, an error will be thrown, app will be terminated.
                    // printing all the messages in red colour to the terminal.
                    std::cout << "\033[31m";  
                    std::cout << "Notepad window with the \"" << notepadWindowTitle << "\" file was not found." << std::endl;
                    std::cout << "Application will be closed..." << std::endl;
                    std::cout << "\033[0m";
                    Sleep(1000);
                    throw std::runtime_error("Notepad was not open");
                }
            }
            Sleep(1000);
        }

    }
    catch (const std::runtime_error& e)
    {
        std::cout << "\033[31m";  
        std::cout << "Error: " << e.what() << std::endl;
        std::cout << "\033[0m";
    }
}
